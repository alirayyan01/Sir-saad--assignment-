// let myarr = new Array()
// myarr.push("Muddasir")

// let myarr = []
// myarr.push("Muddasir")

// let myarr = ["Muddasir", "Ali", "Khan"]
// let myarr = [1,2,3,4,5]
// let myarr = [true, false, true, false]
// let myarr = [1, "Muddasir", true, 1.5]
// let myarr = ["jazz","zong","ufone","telenor","warid"]
// let myarr = ["ssc","hssc","bs","ms","phd","mba","mphil","css"]
// let myarr = ["ssc","hssc","bs","ms","phd","mba","mphil","css"]
// document.write(`
//     1) ${myarr[0]} <br>
//     2) ${myarr[1]} <br>
//     3) ${myarr[2]} <br>
//     4) ${myarr[3]} <br>
//     5) ${myarr[4]} <br>
//     6) ${myarr[5]} <br>
//     7) ${myarr[6]} <br>
//     8) ${myarr[7]} <br>
//     `)
// let myarr = []
// myarr.push("Avengers: Age of Ultron")
// myarr.push("spectre")
// myarr.push("jurassic world")
// myarr.push("inside out")


// document.write( `1) ${myarr[0]}  <br>`)
// document.write( `2) ${myarr[1]}  <br>`)
// document.write( `3) ${myarr[2]}  <br>`)
// document.write( `4) ${myarr[3]}  <br>`)

// document.write("<br><br>lenght of array " + myarr.length)

// let myarr = ["bmw", ,"mercedes", "ferrari" ,"lamborghini", "rolls royce" ,"bugatti"]

// document.write( `
// <h1> FAVorite cars </h1>
// ${myarr}
// first index of array: 0<br>
// car at first index of array: ${myarr[0]}<br>
// last index of array: ${myarr.length - 1}<br>
// car at first index of array: ${myarr[myarr.length - 1]}<br>
// `)

// let myarr1 = ["muddasir", "ali", "yasir"]
// let myarr2 = [165,169,94]

// document.write( `
// score of ${myarr1[0]} is ${myarr2[0]}. percentage: ${myarr2[0]/200*100}%<br>
// score of ${myarr1[1]} is ${myarr2[1]}. percentage: ${myarr2[1]/200*100}%<br>
// score of ${myarr1[2]} is ${myarr2[2]}. percentage: ${myarr2[2]/200*100}%<br>`)




// let myarr = ["blue", "green", "yellow", "red", "black"]

// document.write( myarr)

// let myarr = [564, 654, 765, 876, 987, 1098, 1209]
// let ayarr1 = myarr.sort()
// document.write( `
// score of students: ${myarr}<br>
// ordered score of students: ${ayarr1.reverse()}<br>
// `)

// let myarr = ["Apple", "Banana", "Mango", "Orange", "Strawberry"]
// document.write( `
// Fruits list <br>
// ${myarr}<br>
// ordered Fruits list <br>
// ${myarr.sort()}<br>
// `)
// let myarr = ["karachi", "lahore", "islamabad", "quetta", "peshawar"]

// document.write( `
// Cities list <br>
// ${myarr}<br>
// selected cities list <br>
// ${myarr.slice(2,4)}<br>
// `)
// let myarr = ["This ", "is"," my", " cat"];

// let str = myarr.join("")
// document.write(str)

// let myarr = []
// myarr.push("keyboard")
// myarr.push("mouse")
// myarr.push("printer")
// myarr.push("monitor")



// document.write(`
//     Device: <br>
//     ${myarr}
//     <br>
//     <br>
//     output:<br>
//     ${myarr[0]}<br>
//     output:<br>
//     ${myarr[1]}<br>
//     output:<br>
//     ${myarr[2]}<br>
//     output:<br>
//     ${myarr[3]}<br>
//     `
// )


// let myarr = ["apple","samsung","motorola","nokia","infinix"]

// document.write(`
//     <select>
//     <option>${myarr[0]}</option>
//     <option>${myarr[1]}</option>
//     <option>${myarr[2]}</option>
//     <option>${myarr[3]}</option>
//     <option>${myarr[4]}</option>
//     </select>
//     `)




// let myarr = [[],[],[]]

// let myarr = [[0,1,2,3],[1,0,1,2],[2,1,0,1]]


// document.write(`
//     ${myarr[0]} <br>
//     ${myarr[1]} <br>
//     ${myarr[2]} <br>
//     `)









